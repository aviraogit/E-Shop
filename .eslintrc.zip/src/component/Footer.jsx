import React from 'react'

const Footer = () => {
  return (
    <>
    
    <footer>
        <h4>All Rights Reserved &copy; MY.STORE</h4>
      </footer>
    </>
  )
}

export default Footer